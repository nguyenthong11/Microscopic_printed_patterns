function untitled
for n=1:100
    y = imread(sprintf('dot%01d.bmp',n));
    y = y(:,:,1);
    Y = ones(128);
    Y = MatrixReplace(Y,y);
%     rect = [119 111 69 79];
%     if n>100 && n<=200
%         rect = [3 4 127 127];
%     end
%     if n>200 && n<=300
%         rect = [3 4 127 127];
%     end 
%     if n>300 && n<=400
%         rect = [3 4 127 127];
%     end
%     Y = imcrop(y,rect);
    Y = double(Y);
    Y = ceil(Y/255);
    imshow(Y)
    imwrite(Y,sprintf('dot%01d.bmp',n))
end
end
function A = MatrixReplace(A,B)
    [p,q] = size(B); 
    A(end-p+1:end, end-q+1:end) = B; 
end